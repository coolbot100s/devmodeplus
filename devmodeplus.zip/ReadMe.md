# DevmodePlus
Adds /help, a devmode button, new commands, and a handy interface for modders.
proper documentation coming soon™ 
Example code for adding your mods to /help (it's easy I promise) can be seen in modules/command_register.lua